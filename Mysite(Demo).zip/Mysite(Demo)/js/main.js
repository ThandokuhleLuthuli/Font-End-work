//This function sets teh side navigation to 250px and the left margib of the page content to 250px;
function openNav()
{
    document.getElementById("mysidenav").style.width="250px";
    document.getElementById("main").style.marginLeft="250px";
    document.body.style.backgroundColor="rgba(0,0,0,0.4)";
}

//This function sets the width if the side navigation tom0 and the left margin of the page to 0
function closenav()
{
    document.getElementById("mysidenav").style.width="0";
    document.getElementById("main").style.marginLeft="0";
    document.body.style.backgroundColor="white";
    
}
// if scroll down(event listener)
//go to document
//get element
//get elements style and access the display property  and set it to none

window.onscroll=function()
{
    document.getElementById("arrow").style.display="none";
    document.getElementById("i").style.visibility="hidden";
    //document.getElementsByTagName("section").style.opacity=0;
}
function fo ()
{
    document.getElementById("contact").focus();
}
window.onload=function()
{
    document.getElementById("para").style.visibility="hidden";
}
//success message
var btn=  document.getElementById("sub");
 function sucess()
{
    document.getElementById("name").style.visibility="hidden";
    document.getElementById("mail").style.visibility="hidden";
    document.getElementById("msg").style.visibility="hidden";
    document.getElementsByTagName("label").style.visibility="hidden";
    document.getElementsByTagName("label").style.visibility="hidden";
    document.getElementsByTagName("label").style.visibility="hidden";
    var show = document.getElementById("para").style.visibility="visible";
    show.innerHTML="YOUR MESSAGE HAS BEEN SENT!";
    return show;
}

